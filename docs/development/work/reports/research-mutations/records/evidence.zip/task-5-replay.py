from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

scratch = Path(__file__).resolve().parent
repo = scratch.parents[2]
cli = repo / "target" / "debug" / "hoimin.exe"
assert cli.is_file(), cli


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(label, *arguments):
    output = subprocess.run([cli, *arguments], capture_output=True, timeout=180)
    (scratch / f"task-5-{label}.out").write_bytes(output.stdout)
    (scratch / f"task-5-{label}.err").write_bytes(output.stderr)
    print(label, output.returncode, flush=True)
    assert output.returncode == 0, (label, output.stderr.decode(errors="replace"))
    return output.stdout


def read_plan(label, *arguments):
    stdout = command(label, *arguments)
    saved = scratch / f"task-5-{label}.json"
    saved.write_bytes(stdout)
    return saved, json.loads(stdout)


def report(label, saved, plan):
    expected = plan["candidates"]
    stdout = command(label, "verify", saved, "--top", str(len(expected)))
    path = scratch / f"task-5-{label}.jsonl"
    path.write_bytes(stdout)
    rows = [json.loads(line) for line in stdout.splitlines()]
    assert rows[0]["kind"] == "run_started"
    assert rows[0]["schema_version"] == 10
    assert rows[0]["normalized_config"]["operators"] == plan["normalized_config"]["operators"]
    assert rows[1]["kind"] == "baseline_finished"
    assert rows[1]["termination"] == {"Exit": 0}
    assert rows[-1]["kind"] == "run_finished"
    assert rows[-1]["complete"] is True
    assert len({row["run_id"] for row in rows}) == 1
    assert [row["sequence"] for row in rows] == list(range(1, len(rows) + 1))
    finished = [row for row in rows if row["kind"] == "mutant_finished"]
    # Selection rank is a plan/preview field. Run events carry source edit metadata.
    report_projection = [
        {key: value for key, value in candidate.items() if key not in {"rank", "ranking_reasons", "score"}}
        for candidate in expected
    ]
    assert [row["candidate"] for row in finished] == report_projection
    statuses = Counter(row["status"] for row in finished)
    assert set(statuses) <= {"killed", "survived"}, statuses
    for name in ("killed", "survived"):
        assert rows[-1]["counts"][name] == statuses[name]
    print(label, {row["candidate"]["operator"]: row["status"] for row in finished}, dict(statuses))
    return path, statuses


print(command("cli-version", "--version").decode().strip(), digest(cli))
capture = json.loads((scratch / "prechange-plan-receipt.json").read_bytes())
print("capturing binary", capture["version"], capture["sha256"])
assert capture["version"] == "hoimin 0.14.0"
for item in capture["plans"]:
    saved = Path(item["path"])
    before_plan = digest(saved)
    plan = json.loads(saved.read_bytes())
    config = plan["normalized_config"]
    op_names = config["operators"]
    source = Path(config["selection"]["root"]) / "subject.py"
    before_source = digest(source)
    assert plan["schema_version"] == item["schema"] == 10
    assert plan["ranking_rule_version"] == 4
    assert len(op_names) == item["operators"]
    assert len(plan["candidates"]) == item["candidates"]
    assert plan["truncated"] is False
    assert set(candidate["operator"] for candidate in plan["candidates"]) <= set(op_names)
    if item["name"] == "explicit":
        assert op_names == ["binary_add_sub"]
    options = ["verify", saved, "--top", str(item["candidates"]), "--dry-run"]
    preview = json.loads(command(f"old-{item['name']}-preview", *options))
    assert preview["plan_schema_version"] == 10
    assert preview["ranking_rule_version"] == 4
    assert preview["retained_candidates"] == item["candidates"]
    assert [row["id"] for row in preview["candidates"]] == [row["id"] for row in plan["candidates"]]
    assert [row["rank"] for row in preview["candidates"]] == [row["rank"] for row in plan["candidates"]]
    _, statuses = report(f"old-{item['name']}-verify", saved, plan)
    assert digest(saved) == before_plan
    assert digest(source) == before_source
    print(item["name"], "saved-plan/source digests", before_plan, before_source, dict(statuses))

project = Path(tempfile.mkdtemp(prefix="task-5-mixed-project-", dir=scratch))
source = project / "subject.py"
source.write_text(
    "import re\n"
    "from html import escape\n"
    "events = []\n"
    "def classify(value): return re.fullmatch(r'\\d+', value) is not None\n"
    "def render(value): return escape(value)\n"
    "def cleanup(early):\n"
    "    try:\n"
    "        if early: return 'stopped'\n"
    "    finally: events.append('closed')\n"
    "    return 'done'\n"
    "def retain(values): return [value for value in values if value > 0]\n"
    "def nearest(value): return round(value, 1)\n",
    encoding="utf-8",
    newline="\n",
)
before_source = digest(source)
check = project / "check.py"
weak = (
    "from subject import *\n"
    "assert classify('9')\n"
    "assert render('ab') == 'ab'\n"
    "assert cleanup(False) == 'done'\n"
    "assert events == ['closed']\n"
    "assert retain([1, 2]) == [1, 2]\n"
    "assert nearest(0.0) == 0.0\n"
)
strong = weak + (
    "assert classify('９')\n"
    "assert render('&') == '&amp;'\n"
    "assert cleanup(True) == 'stopped'\n"
    "assert events == ['closed', 'closed']\n"
    "assert retain([-1, 0, 2]) == [2]\n"
    "assert nearest(1.25) == 1.2\n"
)
check.write_text(weak, encoding="utf-8", newline="\n")
operators = [
    "finally_unwrap",
    "stdlib_escape_remove",
    "regex_character_set",
    "comprehension_filter_remove",
    "round_digits_remove",
]
selection = (
    "plan", "--root", project, "--file", "subject.py",
    "--min-free-space", "1B", "--allow-best-effort-memory", "--jobs", "1",
)
test = ("--", sys.executable, "-B", "check.py")
_, defaults = read_plan("mixed-default-plan", *selection, *test)
assert len(defaults["normalized_config"]["operators"]) == 107
assert set(operators) <= {candidate["operator"] for candidate in defaults["candidates"]}
saved, mixed = read_plan(
    "mixed-plan", *selection, "--operators", ",".join(operators), *test
)
mixed_hash = digest(saved)
assert mixed["truncated"] is False
assert {row["operator"] for row in mixed["candidates"]} == set(operators)
assert len(mixed["candidates"]) == len(operators)
before, statuses = report("mixed-before", saved, mixed)
assert statuses == {"survived": len(operators)}
check.write_text(strong, encoding="utf-8", newline="\n")
after, statuses = report("mixed-after", saved, mixed)
assert statuses == {"killed": len(operators)}
progress = json.loads(command("mixed-progress", "progress", before, after))
assert progress["latest"]["state"] == "improving"
assert digest(source) == before_source
assert digest(saved) == mixed_hash
print("Mixed replay", len(operators), "survivors to kills under unchanged candidate IDs", progress["latest"])

