# Task brief 2

## Binding global constraints

- Implement all nine issues; examples are not a cap on semantic scope.
- Keep source analysis in Rust; no GUI, embedded LLM, Python collector or pytest plugin.
- Preserve arbitrary user verification commands and existing plan/verify/report contracts.
- Append stable operator IDs, register adopted runtime operators in defaults and appropriate selectors, and document exclusion by ID.
- Reuse existing selection, source encoding, cancellation and resource-admission paths; discovery must stop when the sink stops.
- Statically unresolved identity is not proof of a standard-library callable. Reject malformed syntax, unsafe binding assumptions and unsupported dynamic expansions explicitly.
- Mutate one semantic site per candidate; preserve unrelated source and evaluation effects unless the chosen fault model changes them.
- Use one test invocation for one case, Arrange/Act/Assert groups, named rstest cases and bounded proptest strategies. Test runtime behavior with actual CPython as well as candidate spans and parsing.
- Record at least five substantive self-review passes at each stage: design, implementation plan, implementation and tests. External reviews supplement these.
- Preserve the original dirty checkout. Work only in the managed research-mutations worktree. Do not push, merge or close issues as part of implementation.


### Task 2: Calls, escaping, argument and result contracts

Read calls-design.md sections for #1192/#1195/#1196. Create rust/call_contracts.rs and tests; extend callable_imports.rs only as needed for guarded dotted imports, reuse optional_keywords.rs signature facts where sound. Modify IDs/defaults/ranking/integration.

- [ ] Add failing tests for re/html/URL escape removal, positional/keyword/boundary swaps and typed call/await results.
- [ ] Record focused RED.
- [ ] Implement preserved evaluation order and scoped binding safeguards. No lambda scope relocation, duplicate evaluation or exception fallback.
- [ ] Add finite runtime witnesses and bounded property cases for parse validity, alias/shadowing, spread rejection, defaults and source encodings.
- [ ] Verify focused and impacted existing tests; record five code/test review passes, commit and report.


Worktree: C:/Users/hayao/.codex/worktrees/research-mutations/hoimin. Build jobs 2, test threads 2. Use --quiet for test output. Runtime CPython: C:/Users/hayao/AppData/Roaming/uv/python/cpython-3.14.9-windows-x86_64-none/python.exe (also 3.15.1). Run exec with explicit workdir. Escalation is needed for build/git/write operations outside original writable root. Never edit original checkout. No subagents. Commit only task paths. Report RED/GREEN commands and exit status, files changed, at least five substantive implementation-review and at least five test-review passes, eight design diagnostic assessment, concerns.

Binding refinement: read the design document Builder-check rulings for positional-versus-keyword swap eligibility. Explicit positional pairs need no signature proof and may belong to a variadic callable; spread syntax remains excluded.

Current shared integration state before Task2: Task1 appended five IDs and added grouped structural traversal state (control_structure.rs and statement_order.rs). Extend rather than replace it. The task1 report records pre-existing Windows CLI lib-test compiler errors and broad Clippy baseline warning assigned to Task5; do not expand Task2 into those fixes. Real CPython available in .venv/Scripts/python.exe. Every unaffected core/analyzer test passed in Task1; focused task2 tests and impacted shared-import tests still required.

Eligibility clarification for call_result_default: wrapping an original call need not rebind its arguments. Keep *args/**kwargs text and evaluation intact when callable identity and the declared/builtin result contract are otherwise proven. Do not inherit escaping/swap expansion restrictions or the optional-keyword operator's async/variadic exclusions wholesale. Preserve those exclusions in the existing optional-keyword behavior. Typed variadic synchronous functions and immediately awaited typed coroutines can still supply a known result contract. Add separate regression cases for these distinctions; invalid/unknown identity remains excluded.


User clarification (2026-11-20): every new mutation operator in all nine issues is opt-out: enabled by default and individually disableable using existing options. No opt-in subset or experimental-default exception. Verify actual default planning and exclusion behavior, including the three earlier issues.
