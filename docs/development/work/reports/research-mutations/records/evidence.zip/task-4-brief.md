# Task brief 4

## Binding global constraints

- Implement all nine issues; examples are not a cap on semantic scope.
- Keep source analysis in Rust; no GUI, embedded LLM, Python collector or pytest plugin.
- Preserve arbitrary user verification commands and existing plan/verify/report contracts.
- Append stable operator IDs, register adopted runtime operators in defaults and appropriate selectors, and document exclusion by ID.
- Reuse existing selection, source encoding, cancellation and resource-admission paths; discovery must stop when the sink stops.
- Statically unresolved identity is not proof of a standard-library callable. Reject malformed syntax, unsafe binding assumptions and unsupported dynamic expansions explicitly.
- Mutate one semantic site per candidate; preserve unrelated source and evaluation effects unless the chosen fault model changes them.
- Use one test invocation for one case, Arrange/Act/Assert groups, named rstest cases and bounded proptest strategies. Test runtime behavior with actual CPython as well as candidate spans and parsing.
- Record at least five substantive self-review passes at each stage: design, implementation plan, implementation and tests. External reviews supplement these.
- Preserve the original dirty checkout. Work only in the managed research-mutations worktree. Do not push, merge or close issues as part of implementation.


### Task 4: Complete regex mutation domain

Read regex-design.md. Create rust/regex.rs with private scanner/source-literal modules if needed, plus regex_tests.rs and actual CPython contracts. Reuse guarded imports/provenance. Modify IDs/defaults/ranking/integration.

- [ ] Add named failing cases for method, anchor and all ASCII/Unicode modes including compiled receivers and aliases.
- [ ] Record focused RED.
- [ ] Implement a bounded Python-regex scanner and source-edit mapping; handle global/external/scoped flags, complements, word boundaries, case folding, bytes and string syntax without pretending Rust regex syntax equals Python syntax.
- [ ] Add bounded proptest compilation/runtime properties and the complete Unicode witness matrix from the domain design. Include specification-dependent ASCII original bug and Unicode intended behavior.
- [ ] Verify focused and impacted tests; record five code/test reviews, commit and report.


Worktree: C:/Users/hayao/.codex/worktrees/research-mutations/hoimin. Build jobs 2, test threads 2. Use --quiet for test output. Runtime CPython: C:/Users/hayao/AppData/Roaming/uv/python/cpython-3.14.9-windows-x86_64-none/python.exe (also 3.15.1). Run exec with explicit workdir. Escalation is needed for build/git/write operations outside original writable root. Never edit original checkout. No subagents. Commit only task paths. Report RED/GREEN commands and exit status, files changed, at least five substantive implementation-review and at least five test-review passes, eight design diagnostic assessment, concerns.

Binding refinement: read the design Builder-check rulings on lazy referenced-literal variants. CandidatePrefix count fullness is not a global stop; preserve ranked unlimited-prefix semantics, cap canonical same-start/operator variants at max_candidates+1, and test long-reference low-budget work.


Completeness refinement (also added to root design, supersedes module-only/single-token shortcuts in domain report): support uniquely initialized unconditional local compiled-pattern and literal variables with sound lexical/rebinding proof, not only module globals. Support atoms crossing implicitly concatenated literal tokens using one covering source replacement that preserves per-token quoting/prefixes and intervening comments while changing only decoded affected pieces. Verify intended decoded pattern and actual CPython compile. Use source mapping and existing budgets; do not omit such atoms merely because their source uses more than one token. Add finite and property regressions for these forms. Unknown/ambiguous bindings remain excluded. You may reuse Task3 provenance helper if its actual guarantees match; do not invent a generic public framework.

Task2 introduced source delimiter-depth admission for wrappers (see its final report/API). A synthesized __import__('re').member inside a deeply parenthesized callee can exceed Python's nesting limit even though the original alias is valid; use the applicable helper and include a CPython boundary regression. Regex parentheses inside string values have their own separate grammar and are not Python source delimiters.

User clarification (2026-11-20): every new mutation operator in all nine issues is opt-out: enabled by default and individually disableable using existing options. No opt-in subset or experimental-default exception. Verify actual default planning and exclusion behavior, including the three earlier issues.

Task2 independent review follow-through: family import resolution is being corrected for explicit callable __globals__ exposure and for harmless immutable stdlib constants. Consume the final fixed API. Add domain-specific direct/aliased Decimal rounding-constant and regex flag positive cases, plus writes/unknown object escapes negative cases; a safe constant argument must not erase all callable provenance for that module. Work must scale with source/supplied argument count even when line/symbol selection excludes calls.

Root independent design probe regex-concat-design-probe.py (scratch workspace) passed CPython3.14.9 and3.15.1, four named witnesses: a backslash/d atom crossing ordinary literal tokens with retained intervening comment; complemented D crossing tokens; canonical [0-9] class spanning raw literals; b boundary crossing tokens. Each hand-written covering replacement preserves per-token prefixes/quotes/comments and yields intended ASCII/Unicode acceptance change. This establishes feasibility only, not analyzer verification. Reproduce equivalent fixtures through emitted analyzer edits during Task4 rather than treating the probe as implementation evidence.

Execution note: all issue bodies were already read and reconciled into the tracked design/domain specifications by the controller. They are sufficient implementation authority; do not repeat remote issue connector lookups. A repeated connector call stalled Task3 for >20minutes. If a genuinely missing upstream detail is necessary, ask root with the specific gap, or use a bounded gh read; normal implementation and CPython semantics can be checked locally.

Task3 handoff API (inspect final reviewed implementation before reuse): local_initializers::Index::build(module, cancelled, |initializer, is_with| -> Option<T>) and get(&ExprName), T:Copy. It proves unique unconditional same-function initialization or a unique module initializer preceding the enclosing definition, with shadow/rebind checks and with-target range lifetime. Regex classifiers should accept only ordinary initialization (not arbitrary with-enter results). Shared source_delimiters module owns depth admission. Task3 initial all-family50 Rust +33 CPython3.14 passed; expanded validation/review still pending when this note was written.

## Regex preparation rulings

The original sole-sensitive-atom duplicate rule must not make candidates depend on which other operator IDs are selected. Excluding one ID removes its candidates; it must not create new candidates under a different ID. A root ASCII/Unicode-mode edit changes observable Pattern.flags/Match.re.flags, whereas an atom-local edit retains root flags. Retain both where those effects differ, even if a boolean-only matcher observes the same acceptance. Deduplicate canonical edits within an operator. Suppress across operators only when true equivalence including relevant observable flags is proven, independently of selection. This supersedes the broader sole-atom suppression wording in regex-design.md. The cost is extra mutants with equivalent outcomes for some boolean-only checks, in exchange for complete mode coverage and predictable opt-out behavior.

Pattern-wide mode sensitivity includes casefold-sensitive literals, escaped singletons and case-insensitive backreferences, in addition to shorthands, boundaries and classes. Examples include Kelvin sign/k and accented letter case pairs under IGNORECASE. Per-atom edits retain the specified category/class/boundary scope. Add real CPython witnesses and suppress clearly mode-insensitive root changes.

Cross-token literal rewriting must preserve prefixes, quotes and comments and also preserve token separation when emptying an unspaced adjacent literal would otherwise form a triple-quote opener. Verify raw-string trailing-backslash parity and decoded output against Ruff. These are source-preservation requirements, not reasons to exclude the entire representation.

Clarification of selection independence: it concerns semantic eligibility and canonical per-operator edit descriptors before shared budgets. Existing ranked candidate/payload limits still apply to the resulting selected set; excluding an operator can naturally free capacity for later candidates. Preserve unlimited-prefix semantics under each selection. Do not make duplicate elimination conditional on whether another operator is enabled.
