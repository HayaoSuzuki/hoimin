# Final consolidated mutation review fixes

Read final-review.md in this scratch directory for all five Important findings verbatim, their concrete witnesses, and the review evidence. Resolve all five in one consolidated fix wave. The root design's Final review refinements settle the older domain omission; regex-design.md now agrees. The user requires the complete nine-issue scope, all default-enabled and individually excludable.

Reviewed fix base: 6df6dcb7deec71946845043408d4ce256dc55044. Start implementation from d46582228664b054272b5ce29b0533aa98219e4d, whose only added changes are the controller's design clarification. The eventual fix-review package includes both that clarification and your code changes.

## Global constraints

- Implement all nine issues; examples are not a cap on semantic scope.
- Keep source analysis in Rust; no GUI, embedded LLM, Python collector or pytest plugin.
- Preserve arbitrary user verification commands and existing plan/verify/report contracts.
- Append stable operator IDs, register adopted runtime operators in defaults and appropriate selectors, and document exclusion by ID.
- Reuse existing selection, source encoding, cancellation and resource-admission paths; discovery must stop when the sink stops.
- Statically unresolved identity is not proof of a standard-library callable. Reject malformed syntax, unsafe binding assumptions and unsupported dynamic expansions explicitly.
- Mutate one semantic site per candidate; preserve unrelated source and evaluation effects unless the chosen fault model changes them.
- Use one test invocation for one case, Arrange/Act/Assert groups, named rstest cases and bounded proptest strategies. Test runtime behavior with actual CPython as well as candidate spans and parsing.
- Record at least five substantive self-review passes at each stage: design, implementation plan, implementation and tests. External reviews supplement these.
- Preserve the original dirty checkout. Work only in the managed research-mutations worktree. Do not push, merge or close issues as part of implementation.


## Required findings

1. Share explicit module-namespace hazard knowledge with initializer proofs. Verify function.__globals__ writes/escapes and direct globals consistency for module set receivers and module reads inside function bodies. Preserve proven function-local sets and ordinary controls. Avoid a second independently maintained hazard heuristic.
2. Support a root mode declared inline and externally with a single covering edit. Include both directions, module/compiled calls, referenced and concatenated literals, aliases, reordered keywords, other flags, scoped overrides, comments, selection, and actual CPython acceptance/Pattern.flags. Do not alter unrelated reference consumers or add a multi-edit wire format.
3. For unknown flags and known literal contents, share possible-grammar validation between direct and compiled method mutations. Reject universally malformed literals; preserve dynamic patterns and flag-dependent valid literals, including a VERBOSE-sensitive control. Reuse bounded cancellation-aware grammar work.
4. Avoid full referenced-literal materialization for provably losing candidates before prefix admission. Put the conservative decision behind the common admission abstraction, not a regex-specific copy of ranking policy. Preserve later better-ranked candidates, canonical duplicates, K+1 overflow witness, selection, failed sinks and cancellation. Use the generated-byte counter for many positive-result references, bounded versus unlimited exact-prefix equality, and controls for later better-ranked candidates. Requested output cost is distinct from copying rejected candidates.
5. Thread the actual cancellation callback through imported-name and lexical signature indexing. Return cancellation without publishing partial facts. Add bounded stage-specific callback tests and retain no-cancellation/optional-keyword behavior.

Also resolve the heap-test granularity finding: one named shape/selector row per invocation, retaining the common measurement mutex, fixtures and K; the 4-shape x 3-selector comparison becomes 12 independently identifiable cases. Remove the redundant suite-forwarding name by defining the single visit_suite entry in the order module; preserve traversal/cancellation semantics. The existing Git CRLF warning is informational and requires no global Git change.

## Implementation and evidence

First reproduce each claimed defect with a focused failing test or precise code/probe evidence. Test each fix independently, then run affected common regression suites. Record five substantive implementation and five test self-review passes, plus all eight software-design diagnostics with evidence and residual limitations. Use technical-documentation for touched docs; update claims when behavior changes.

Run in C:/Users/hayao/.codex/worktrees/research-mutations/hoimin with explicit workdir and managed escalation for writes/builds. Use two Cargo jobs and two test threads, quiet output. To avoid debug-artifact capacity exhaustion, use CARGO_PROFILE_DEV_DEBUG=0, CARGO_PROFILE_TEST_DEBUG=0, CARGO_INCREMENTAL=0 as CI does; keep debug assertions. Managed CPython executables are C:/Users/hayao/AppData/Roaming/uv/python/cpython-3.14.9-windows-x86_64-none/python.exe and the analogous cpython-3.15.1 path; use HOIMIN_OPERATOR_TEST_PYTHON for runtime contracts. No subagents, remote issue re-fetch, original-checkout edits, push, merge or issue closure.

Appropriate final verification covers the full analyzer library and affected shared name/admission/ranking/selection/budget tests, the research runtime/saved contracts on both interpreters, the 12-case heap matrix, strict workspace lint/format, generated docs checks if touched, and the actual old/mixed replay script after rebuilding the final CLI. Reuse exact existing commands/report and .superpowers/sdd/research-mutations/task-5-replay.py; do not regenerate old0.14 plans. Broaden only for actual new risk/failure. Do not rerun the already diagnosed unrelated native workspace suite merely to reproduce its29 inherited failures. Those remain explicitly disclosed; no all-green claim.

Full baseline/integration evidence is docs/development/work/reports/research-mutations/integration-implementation.md. No verification commands are currently running. Only this worker owns source edits. Commit task-only paths, preserving root scratch ledger and plan checkboxes. Append complete receipts/findings to final-fixes-report.md here and copy the final report to docs/development/work/reports/research-mutations/final-fixes.md. Return concise DONE/concerns, commit range, tests and remaining risks. The controller dispatches one scoped re-review of the consolidated changes.
