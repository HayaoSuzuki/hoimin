use std::{fs, path::PathBuf};

fn main() {
    let scratch = PathBuf::from(".superpowers/sdd/research-mutations");
    let regular = scratch.join("prechange-plan-project").join("subject.py");
    let plain = scratch.join("nonexistent-task-5/..");
    let canonical = fs::canonicalize(&scratch).unwrap();
    let verbatim = PathBuf::from(format!(r"{}\nonexistent-task-5\..", canonical.display()));
    println!("plain parent: {:?}", fs::canonicalize(plain));
    println!("verbatim parent: {:?}", fs::canonicalize(verbatim));
    println!("under regular file: {:?}", fs::metadata(regular.join("child")).unwrap_err().kind());
}
