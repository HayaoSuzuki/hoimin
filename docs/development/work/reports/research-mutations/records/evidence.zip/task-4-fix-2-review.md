**Mode-sensitive whitespace unions lose both operators. — ADDRESSED.** At head 4a6ce2da, crates/hoimin-python/src/analyzer/rust/regex/atoms.rs:170 adds U+001C–U+001F to the Unicode low-code-point whitespace mask. The coverage check at :204 requires all low 128 code points in both modes alongside full high-range coverage. Both whitespace and its complement use the mode's mask.

**Regression evidence.** crates/hoimin-python/src/analyzer/rust/regex_tests.rs:479 exercises the positive and negated classes under each operator and retains suppression when the four missing characters are supplied. crates/hoimin-cli/tests/behavioral_research/regex.rs:599 checks each emitted atom and root edit against both signs and the two adjacent controls. The appended receipts in docs/development/work/reports/research-mutations/regex-implementation.md:106 record six new analyzer cases, six existing universal-class controls and four runtime cases per interpreter on CPython 3.14.9 and 3.15.1. The reported six-character result vectors agree with the independent round-one witnesses.

**New breakage in the fix diff:** None identified. **Out-of-scope observations:** None added.

**Fix round: All findings addressed, no new Critical/Important breakage.** The Task 4 review gate passes.
