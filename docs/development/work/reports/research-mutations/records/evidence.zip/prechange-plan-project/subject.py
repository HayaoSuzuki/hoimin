def adjust(value) -> int:
    return value + 1
result = adjust(2)
