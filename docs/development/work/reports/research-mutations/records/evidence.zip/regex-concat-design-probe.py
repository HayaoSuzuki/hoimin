import re
import sys

cases = [
    ('digit', r'''pattern = ("\\"
    # retained comment
    "d+")''', r'''pattern = ("[0-9]"
    # retained comment
    "+")''', '１２３', True, False),
    ('complement', r'''pattern = ("\\" "D")''', r'''pattern = ("[^0-9]" "")''', '١', False, True),
    ('ascii_class', r'''pattern = (r"[0-" r"9]+")''', r'''pattern = (r"\d" r"+")''', '١٢٣', False, True),
    ('boundary', r'''pattern = ("\\" "bé")''', r'''pattern = ("(?a:\\b)" "é")''', 'é', True, False),
]
for name, source, replacement, subject, expected_before, expected_after in cases:
    before, after = {}, {}
    exec(compile(source, '<original>', 'exec'), before)
    exec(compile(replacement, '<replacement>', 'exec'), after)
    observed = (bool(re.fullmatch(before['pattern'], subject)), bool(re.fullmatch(after['pattern'], subject)))
    assert observed == (expected_before, expected_after), (name, observed)
    print(name, observed)
print(sys.version.split()[0], 'four design witnesses passed; not an analyzer verification')
