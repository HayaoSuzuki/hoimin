# Task brief 1

## Binding global constraints

- Implement all nine issues; examples are not a cap on semantic scope.
- Keep source analysis in Rust; no GUI, embedded LLM, Python collector or pytest plugin.
- Preserve arbitrary user verification commands and existing plan/verify/report contracts.
- Append stable operator IDs, register adopted runtime operators in defaults and appropriate selectors, and document exclusion by ID.
- Reuse existing selection, source encoding, cancellation and resource-admission paths; discovery must stop when the sink stops.
- Statically unresolved identity is not proof of a standard-library callable. Reject malformed syntax, unsafe binding assumptions and unsupported dynamic expansions explicitly.
- Mutate one semantic site per candidate; preserve unrelated source and evaluation effects unless the chosen fault model changes them.
- Use one test invocation for one case, Arrange/Act/Assert groups, named rstest cases and bounded proptest strategies. Test runtime behavior with actual CPython as well as candidate spans and parsing.
- Record at least five substantive self-review passes at each stage: design, implementation plan, implementation and tests. External reviews supplement these.
- Preserve the original dirty checkout. Work only in the managed research-mutations worktree. Do not push, merge or close issues as part of implementation.


### Task 1: Structural control-flow mutations

Read control-design.md. Create rust/control_structure.rs (or focused finally/match/order modules if cohesive separation is necessary), rust/research_control_tests.rs and CLI behavioral contracts. Modify rust.rs traversal, core/config.rs IDs/defaults, CLI ranking and directly affected fixtures.

- [ ] Write named failing tests for finally_unwrap, match arm deletion, guard alteration, OR deletion, statement_order_swap, including illegal reachability and binding rejection.
- [ ] Run focused Rust tests and record RED before adding emitters.
- [ ] Implement token-aligned structural edits, preserving suite bytes and multiline literals; visit module and nested suites without duplicate emission.
- [ ] Add bounded property tests for parse-valid edits and executable normal/abrupt cleanup, pattern fallback and state/notification ordering.
- [ ] Run focused tests and relevant existing analyzer/core suites; record five code and five test reviews, fix findings, commit task-only paths and report.


Worktree: C:/Users/hayao/.codex/worktrees/research-mutations/hoimin. Build jobs 2, test threads 2. Use --quiet for test output. Runtime CPython: C:/Users/hayao/AppData/Roaming/uv/python/cpython-3.14.9-windows-x86_64-none/python.exe (also 3.15.1). Run exec with explicit workdir. Escalation is needed for build/git/write operations outside original writable root. Never edit original checkout. No subagents. Commit only task paths. Report RED/GREEN commands and exit status, files changed, at least five substantive implementation-review and at least five test-review passes, eight design diagnostic assessment, concerns.

