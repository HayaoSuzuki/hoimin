# Task 1 independent review

Review base909bfe85, headb03a5db6. Spec compliance: issues found. Task quality: needs fixes. Critical: none.

## Important findings (verbatim)

1. A swap can reattach a leading lint directive. statement_order.rs:129 scans from the first statement onward. In # pylint: disable-next=not-callable followed by first() and second() on separate lines, the swap transfers the suppression to second(). Check directives attached to the first statement from the preceding line and add a named negative case.
2. A forced guard can exceed CPython’s delimiter limit. control_structure.rs:109 adds two parenthesis levels inside the original grouping. An in-memory CPython 3.14.9 probe compiled a guard with 200 pairs around ready. Applying the emitted wrapper raised SyntaxError: too many nested parentheses. The unchanged depth check at rust/depth.rs:44 counts AST nodes, so redundant grouping does not consume that budget. Account for delimiter depth before admission and cover the boundary with a CPython regression.
3. Private-name mangling defeats the dependency check for swaps. statement_order.rs:51, :77, and :118 compare identifier spellings. Inside class K’s method, __x = int(2) followed by print(_K__x) uses one local slot. CPython printed 2 in the original order and raised UnboundLocalError after exchanging the statements. Resolve private names in their enclosing class context or conservatively reject ambiguous pairs.
4. The duplicate mapping-key check misses equal large integers and floats. At control_structure.rs:281, the pinned Ruff HashableExpr normalizes integers only through u64 (ruff_python_ast-0.0.22/src/comparable.rs:2160). CPython rejected {18446744073709551616: a, 18446744073709551616.0: b} as a duplicate-key pattern. The validator stores these as distinct keys and admits dispatch edits from compiler-invalid input. Compare these values exactly or conservatively decline dispatch edits when equality is unresolved.

## Minor findings for final integration

- Add separate executable cases where return/raise inside cleanup replaces a pending exception.
- The suite walker owns the directive cache initialization/lifetime (rust.rs:3232, statement_order.rs:102). Let the order module own this state. Design assessment7.5/10: six of eight rows supported; design-time percentage still unmeasured.

## Verification limits

New saved-plan roundtrips are covered. Loading a pre-change plan and public CLI diff/symbol selection not demonstrated in this diff. Windows CLI unit compile and baseline warnings are reported separately; baseline nature cannot be proven from this patch. Reviewer used focused CPython probes and pinned equality source for named risks, did not rerun suites.
