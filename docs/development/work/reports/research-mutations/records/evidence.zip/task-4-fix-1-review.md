1. **Repeated discovery of a compiled pattern can cost quadratic time and yield zero candidates.** — ADDRESSED. crates/hoimin-python/src/analyzer/rust/regex.rs:367 skips ineligible compiled consumers before decoding. At :327 the constructor-validity cache serves method uses, and :69 keys reused grammar by literal range, flags and match context. rust/regex_tests.rs:337 and :425 assert one scan for 24 consumers and for consumers selected independently of their constructor.
2. **Statically known byte/text mismatches still produce candidates.** — ADDRESSED. rust/regex.rs:294 classifies formatted strings as text and :375 checks the underlying pattern against the subject. rust/regex_tests.rs:373 covers each direction, compiled receivers and named bindings. crates/hoimin-cli/tests/behavioral_research/regex.rs:494 includes successful dynamic controls.
3. **A malformed numeric conditional releases edits for the rest of the pattern.** — ADDRESSED. rust/regex/pattern.rs:213 and :436 apply the same bounded decimal conversion to quantifiers and numeric conditionals. The tests at behavioral_research/regex.rs:525 assert one candidate and successful matching at 4,300 digits, and zero candidates and CPython ValueError at 4,301.
4. **A universal character class yields a provably ineffective atom mutation and an ineligible root mutation.** — ADDRESSED for the reported universal interval, its negation and reordered covering ranges. rust/regex/atoms.rs:181 merges intervals and :294 suppresses the two candidates. behavioral_research/regex.rs:553 exercises actual universal and near-universal controls. The broader suppression introduced an independent false positive in the universality test, below.

### New breakage in the fix diff

**Important — mode-sensitive whitespace unions lose both operators.** crates/hoimin-python/src/analyzer/rust/regex/atoms.rs:168 and :294. With pattern r'[\S\x09-\x0d\x20\x80-\U0010ffff]', the six explicit ASCII whitespace characters plus the mask used for \S cover all low 128 bits in ascii_members(). The explicit high range covers the rest. The new early return therefore publishes no character-set or root-mode candidate. Unicode \S excludes four additional ASCII control characters, U+001C through U+001F. Each gives a real behavioral difference. Require full coverage of the low 128 code points independently under both modes before suppressing either operator. Include both signs and the two operator IDs in a regression, with U+001B and U+0020 as unchanged neighbors.

**Focused check.** On both CPython 3.14.9 and 3.15.1, fullmatch on each of U+001C–001F returned false for the positive class in default Unicode mode and true in ASCII mode. The negated class reversed every result. U+001B and U+0020 agreed across modes. This in-memory probe directly exercises the gap in behavioral_research/regex.rs:571, whose mixed-union tests sample only U+212A.

### Out-of-scope observations

The three previous Minor items remain assigned to Task 5. No additional outside-diff findings. The appended implementation report at docs/development/work/reports/research-mutations/regex-implementation.md:96 records the targeted RED/GREEN evidence, 101 analyzer passes, 15 fix-specific runtime passes per interpreter, four allocator passes and clean lint/format exits. No passed suite was repeated.

### Verdict

**Fix round: Findings remain open.** All four original findings were addressed at 0687b638. The new Important whitespace-union suppression blocks approval.
