# Task brief 3

## Binding global constraints

- Implement all nine issues; examples are not a cap on semantic scope.
- Keep source analysis in Rust; no GUI, embedded LLM, Python collector or pytest plugin.
- Preserve arbitrary user verification commands and existing plan/verify/report contracts.
- Append stable operator IDs, register adopted runtime operators in defaults and appropriate selectors, and document exclusion by ID.
- Reuse existing selection, source encoding, cancellation and resource-admission paths; discovery must stop when the sink stops.
- Statically unresolved identity is not proof of a standard-library callable. Reject malformed syntax, unsafe binding assumptions and unsupported dynamic expansions explicitly.
- Mutate one semantic site per candidate; preserve unrelated source and evaluation effects unless the chosen fault model changes them.
- Use one test invocation for one case, Arrange/Act/Assert groups, named rstest cases and bounded proptest strategies. Test runtime behavior with actual CPython as well as candidate spans and parsing.
- Record at least five substantive self-review passes at each stage: design, implementation plan, implementation and tests. External reviews supplement these.
- Preserve the original dirty checkout. Work only in the managed research-mutations worktree. Do not push, merge or close issues as part of implementation.


### Task 3: Collection processing and precision mutations

Read calls-design.md sections for #1198/#1199. Create rust/collection_processing.rs and rust/rounding.rs plus focused tests and runtime contracts. Reuse Task 2 callable identity helpers without changing established behavior. Modify IDs/defaults/ranking/integration.

- [ ] Add failing cases for comprehension/filter selection, set union/intersection, sum/count, rounding functions/digits, Decimal modes/quantum/context and intermediate rounding.
- [ ] Record focused RED.
- [ ] Implement each semantic family with statically justified bindings and bounded emitters, preserving non-target argument effects.
- [ ] Add meaningful bounded numeric/comprehension properties and executable ties, negatives, context and intermediate-rounding examples.
- [ ] Verify focused and impacted tests; record five code/test reviews, commit and report.


Worktree: C:/Users/hayao/.codex/worktrees/research-mutations/hoimin. Build jobs 2, test threads 2. Use --quiet for test output. Runtime CPython: C:/Users/hayao/AppData/Roaming/uv/python/cpython-3.14.9-windows-x86_64-none/python.exe (also 3.15.1). Run exec with explicit workdir. Escalation is needed for build/git/write operations outside original writable root. Never edit original checkout. No subagents. Commit only task paths. Report RED/GREEN commands and exit status, files changed, at least five substantive implementation-review and at least five test-review passes, eight design diagnostic assessment, concerns.

Binding refinement: reject named-expression/yield constructs inside the iterable moved into aggregate_sum_count's generator. Add a CPython compile regression for sum((items := source())).


Duplication review before Task3: literal True/False comprehension conditions are already covered by boolean_literal; avoid emitting the same truth change again as filter removal/inversion (True removal is also a no-op). Likewise inversion of a top-level not condition is covered by remove_not. Test separate literal-bool and existing-not exclusions, alongside positive nonliteral conditions, so new default operators add distinct fault models. Do not infer broad semantic equivalence for arbitrary predicates.

For single identity/membership comparisons, filter inversion is likewise already represented by identity/membership (is/is not, in/not in); avoid that provable duplicate. Keep inversion of generic ==/!= comparisons: user-defined __eq__ and __ne__ need not be complements, so replacing a comparison operator is not generally equivalent to negating its result. Chained comparisons remain distinct. Add finite witnesses/rejection cases for these boundaries rather than broad equivalence guesses.

Task2 is introducing a private cached sparse source delimiter-depth index to prevent CPython-invalid wrappers at the200-level source delimiter boundary (AST depth omits redundant parentheses). Inspect its final actual API and reuse where your filter/sum-count/rounding-removal/digits wrappers add nesting; include actual CPython boundary cases. Guarded __import__ destinations in parenthesized callees can also add nesting. Do not reparse entire modules per candidate.

User clarification (2026-11-20): every new mutation operator in all nine issues is opt-out: enabled by default and individually disableable using existing options. No opt-in subset or experimental-default exception. Verify actual default planning and exclusion behavior, including the three earlier issues.

Integration detail from completed Task2: DelimiterDepth is currently private inside call_contracts.rs. For reuse by Task3/4, a focused extraction into a private source-delimiter module is authorized; preserve its behavior and call-contract coverage, expose only build/admission concepts, and keep sparse storage/cancellation. Do not duplicate the depth scan or expand the public API. New domain-local provenance helpers for uniquely initialized receivers are authorized where current APIs cannot express the needed proof; organize by knowledge, not traversal phases.

Task2 independent review follow-through: family import resolution is being corrected for explicit callable __globals__ exposure and for harmless immutable stdlib constants. Consume the final fixed API. Add domain-specific direct/aliased Decimal rounding-constant and regex flag positive cases, plus writes/unknown object escapes negative cases; a safe constant argument must not erase all callable provenance for that module. Work must scale with source/supplied argument count even when line/symbol selection excludes calls.
