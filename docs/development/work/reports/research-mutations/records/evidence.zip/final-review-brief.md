# Final whole-branch review brief

Review all nine researched mutation issues (#1190-1192, #1195-1200) and their integration against the root design and domain specifications. This is the broad final review after all task gates, not another isolated task review.

Base: 4cf630f977dc266c6633969b57d0f9f251bb91d8. The dispatch supplies final HEAD and the prepared full review package.

## Global constraints

- Implement all nine issues; examples are not a cap on semantic scope.
- Keep source analysis in Rust; no GUI, embedded LLM, Python collector or pytest plugin.
- Preserve arbitrary user verification commands and existing plan/verify/report contracts.
- Append stable operator IDs, register adopted runtime operators in defaults and appropriate selectors, and document exclusion by ID.
- Reuse existing selection, source encoding, cancellation and resource-admission paths; discovery must stop when the sink stops.
- Statically unresolved identity is not proof of a standard-library callable. Reject malformed syntax, unsafe binding assumptions and unsupported dynamic expansions explicitly.
- Mutate one semantic site per candidate; preserve unrelated source and evaluation effects unless the chosen fault model changes them.
- Use one test invocation for one case, Arrange/Act/Assert groups, named rstest cases and bounded proptest strategies. Test runtime behavior with actual CPython as well as candidate spans and parsing.
- Record at least five substantive self-review passes at each stage: design, implementation plan, implementation and tests. External reviews supplement these.
- Preserve the original dirty checkout. Work only in the managed research-mutations worktree. Do not push, merge or close issues as part of implementation.


## Inputs

- Root design: docs/development/work/designs/2026-11-20-research-mutations.md and linked control-design.md, calls-design.md, regex-design.md. Later root refinements take precedence over superseded domain wording.
- Plan: docs/development/work/plans/2026-11-20-research-mutations.md.
- Implementation evidence: docs/development/work/reports/research-mutations/{control,calls,processing,regex}-implementation.md, and the final Task5 report identified in dispatch.
- Ledger: .superpowers/sdd/research-mutations/progress.md. Review every deferred-minor/parked entry and its integration disposition. No unresolved Important finding should be silently discarded.
- Task5 brief and report: .superpowers/sdd/research-mutations/task-5-{brief,report}.md.

All new operators are opt-out: enabled by default and individually disableable using existing options. No experimental default exception. The supplied issue specifications are complete; no remote issue re-fetch is needed.

## Review method

Use requesting-code-review/code-reviewer.md and software-design-philosophy. Supply severity, exact evidence, both implementation/spec verdict and design diagnostic score. Include every behavior declined to judge and the reason; root will adjudicate it. The spec is a vision, not permission to ignore reasonable behavior that it did not enumerate.

Read the supplied diff package once in manageable chunks; do not regenerate it or crawl without a concrete risk. Existing passing test evidence need not be rerun. A focused probe is appropriate for a specific unresolved doubt, with the risk and result recorded. Do not edit source, index, HEAD, or branches. No subagents. The only permitted new file is the durable final review report named in dispatch.

Use existing selection, encoding, saved-plan, arbitrary verification-command, resource, cancellation and stable-ID contracts as cross-family integration review lenses. Verify one semantic case per test invocation, AAA, named parameterization and meaningful bounded properties. External reviews supplement, rather than replace, the requested five self-review passes per stage.

## Specific controller review risk

Check a valid pattern that expresses the same mode in both places, e.g. `re.compile(r'(?a)\d', re.A)`, and the Unicode analogue, against root-mode mutation. A rewrite of only one spelling may conflict with the other; a conservative omission may also need justification against complete mode support. This is an unresolved risk from reasoning, not an established defect or a prescribed fix. Inspect the actual emitter/eligibility proof and use a small CPython/analyzer witness if the diff does not settle it. Preserve all other flag bits and scoped overrides.
