set -u
actual_as=$(/usr/bin/prlimit --as=2147483648 -- /bin/sh -c 'ulimit -v')
printf 'actual_as_kib=%s\n' "$actual_as"
test "$actual_as" = 2097152 || exit 1
/usr/bin/prlimit --as=1048576 -- /bin/true
as_status=$?
printf 'small_as_limit_exit=%s\n' "$as_status"
test "$as_status" -ne 0 || exit 1
/usr/bin/timeout --signal=KILL 30s /bin/bash -c 'sleep 90 & printf "%s\n" "$!" > /tmp/hoimin-limit-child.pid; wait'
timeout_status=$?
printf 'timeout_exit=%s\n' "$timeout_status"
test "$timeout_status" -ne 0 || exit 1
child_pid=$(cat /tmp/hoimin-limit-child.pid)
child_state=gone
if test -r "/proc/$child_pid/stat"; then
 read -r ignored_pid ignored_name child_state ignored_rest < "/proc/$child_pid/stat"
fi
printf 'descendant_state=%s\n' "$child_state"
case "$child_state" in Z|gone) exit 0;; *) exit 1;; esac
