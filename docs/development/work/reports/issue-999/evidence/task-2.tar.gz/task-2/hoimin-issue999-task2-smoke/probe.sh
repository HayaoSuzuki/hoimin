#!/bin/bash
set -euo pipefail
cd /tmp
cargo creusot new smoke_crate
cd smoke_crate
python3 - <<'PY'
from pathlib import Path
p=Path('Cargo.toml')
s=p.read_text().replace('creusot-std = "0.14.0"', 'creusot-std = { path = "/opt/creusot/src/creusot/creusot-65349025c67e69fcd7479f1f420fa5904f69bc27/creusot-std" }')
p.write_text(s)
PY
cp /opt/creusot/data/why3find.json why3find.json
printf 'smoke_source:\n'
cat src/lib.rs
printf 'smoke_manifest:\n'
cat Cargo.toml
printf 'generation_start=%s\n' "$(date -u +%FT%TZ)"
/usr/bin/time -v /usr/bin/timeout --signal=KILL 300s cargo creusot --only=coma -j 2 -- --target x86_64-unknown-linux-gnu
printf 'generation_end=%s\n' "$(date -u +%FT%TZ)"
find verif -type f -name '*.coma' -print
