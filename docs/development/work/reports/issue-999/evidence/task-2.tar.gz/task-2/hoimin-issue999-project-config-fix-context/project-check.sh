#!/bin/bash
set -euo pipefail
root=/tmp/project-check
mkdir -p "$root"
cp /opt/creusot/data/why3find.json "$root/why3find.json"
python3 /recipe/tools/creusot_environment.py check --manifest /recipe/formal/creusot/toolchain.json --project-root "$root"
printf 'MATCHING_PROJECT_CHECK=pass\n'
python3 - <<'PY'
import json
from pathlib import Path
p=Path('/tmp/project-check/why3find.json')
data=json.loads(p.read_text())
data['time']=99.0
p.write_text(json.dumps(data))
PY
if python3 /recipe/tools/creusot_environment.py check --manifest /recipe/formal/creusot/toolchain.json --project-root "$root" > /tmp/drift.log 2>&1; then
  cat /tmp/drift.log
  echo 'DRIFT_CHECK=unexpected_success'
  exit 1
fi
cat /tmp/drift.log
printf 'DRIFT_CHECK=rejected\n'
rm "$root/why3find.json"
if python3 /recipe/tools/creusot_environment.py check --manifest /recipe/formal/creusot/toolchain.json --project-root "$root" > /tmp/missing.log 2>&1; then
  cat /tmp/missing.log
  echo 'MISSING_CHECK=unexpected_success'
  exit 1
fi
cat /tmp/missing.log
printf 'MISSING_CHECK=rejected\n'
