#!/bin/bash
set -euo pipefail
cd /workspace
export CARGO_TARGET_DIR=/tmp/hoimin-issue999-target CARGO_BUILD_JOBS=2
mkdir -p /task3-evidence
sha256sum Cargo.toml Cargo.lock crates/hoimin-budget-math/Cargo.toml crates/hoimin-budget-math/src/*.rs why3find.json > /task3-evidence/final-source.sha256
df -k /workspace > /task3-evidence/disk-before.log
check() {
  python3 /recipe/tools/creusot_environment.py check --manifest /recipe/formal/creusot/toolchain.json --project-root /workspace
}
for target in x86_64-unknown-linux-gnu aarch64-apple-darwin x86_64-pc-windows-msvc; do
  for round in first warm; do
    out=/task3-evidence/$target/$round
    mkdir -p "$out"
    cargo clean -p hoimin-budget-math --target "$target"
    rm -rf /workspace/verif/hoimin_budget_math_rlib
    check > "$out/preflight-generation.log" 2>&1
    /usr/bin/time -v timeout --signal=KILL 300s cargo creusot -p hoimin-budget-math --only=coma --span-mode relative -j 2 -- --lib --locked --target "$target" > "$out/generation.log" 2>&1
    test -s verif/hoimin_budget_math_rlib/projection/project_top_budget.coma
    if [[ "$round" == warm ]]; then
      while IFS= read -r -d '' strategy; do
        dest=${strategy#"/task3-evidence/$target/first/"}
        mkdir -p "$(dirname "$dest")"
        cp "$strategy" "$dest"
      done < <(find "/task3-evidence/$target/first/verif" -name proof.json -print0)
      replay=--replay
    else
      replay=
    fi
    check > "$out/preflight-proof.log" 2>&1
    /usr/bin/time -v timeout --signal=KILL 600s cargo creusot -p hoimin-budget-math --only=prove --no-cache $replay -j 2 --why3find-arg=--goals > "$out/proof.log" 2>&1
    sha256sum --check /task3-evidence/final-source.sha256 > "$out/source-check.log"
    cp /task3-evidence/final-source.sha256 "$out/source.sha256"
    cp -r verif "$out/verif"
    printf '%s %s complete\n' "$target" "$round"
  done
done
df -k /workspace > /task3-evidence/disk-after.log
du -sk /tmp/hoimin-issue999-target /task3-evidence > /task3-evidence/owned-disk.log
