from pathlib import Path
import subprocess
import time
import json
import hashlib

root=Path('/workspace')
base=root/'crates/hoimin-budget-math/src'
original={name:(base/name).read_text() for name in ('projection.rs','duration.rs')}
cases=[
 ('ceil','projection.rs','selected / jobs + usize::from(!selected.is_multiple_of(jobs))','selected / jobs','projection/project_top_budget.coma','vc_project_top_budget'),
 ('saturation','projection.rs','if nanos > Duration::MAX.as_nanos() {\n        return Duration::MAX;','if nanos > Duration::MAX.as_nanos() {\n        return Duration::ZERO;','projection/saturating_duration_mul.coma','vc_saturating_duration_mul'),
 ('auto','duration.rs','.checked_mul(2)','.checked_mul(3)','duration/auto_mutant_timeout.coma','vc_auto_mutant_timeout'),
 ('structural_equality','projection.rs','            && self.projected_capacity == other.projected_capacity','','projection/impl_PartialEq_for_TopBudgetProjection/eq.coma','vc_eq_TopBudgetProjection'),
 ('equality','projection.rs','        self.projected_capacity > self.remaining','        self.projected_capacity >= self.remaining','projection/impl_TopBudgetProjection/is_shortfall.coma','vc_is_shortfall'),
]
check=['python3','/recipe/tools/creusot_environment.py','check','--manifest','/recipe/formal/creusot/toolchain.json','--project-root','/workspace']
results=[]
try:
 for name, file, old, new, coma, goal in cases:
  out=Path('/task3-evidence/sensitivity')/name
  out.mkdir(parents=True,exist_ok=True)
  assert original[file].count(old)==1,(name,'ambiguous mutation')
  (base/file).write_text(original[file].replace(old,new))
  (out/'mutation.json').write_text(json.dumps({'file':file,'before':old,'after':new,'goal':goal},indent=2)+'\n')
  commands=[('preflight-generation',check),('clean',['cargo','clean','-p','hoimin-budget-math','--target','x86_64-unknown-linux-gnu']),('generation',['cargo','creusot','-p','hoimin-budget-math','--only=coma','--span-mode','relative','-j','2','--','--lib','--locked','--target','x86_64-unknown-linux-gnu']),('preflight-proof',check)]
  for label,command in commands:
   with (out/(label+'.log')).open('w') as log:
    subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
  relevant=root/'verif/hoimin_budget_math_rlib'/coma
  assert relevant.stat().st_size>0
  (out/'obligation.coma').write_bytes(relevant.read_bytes())
  (out/'source-sha256.json').write_text(json.dumps({name:hashlib.sha256((base/name).read_bytes()).hexdigest() for name in original},indent=2)+'\n')
  command=['cargo','creusot','-p','hoimin-budget-math','--only=prove','--no-cache','-j','2','--why3find-arg=--goals',str(relevant)]
  start=time.monotonic()
  with (out/'proof.log').open('w') as log:
   result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=300)
  content=(out/'proof.log').read_text()
  assert result.returncode != 0,(name,'unexpected proof success')
  assert f'Goal {goal}: ✘' in content,(name,'no relevant unproved goal',content)
  results.append({'name':name,'generation_exit':0,'proof_exit':result.returncode,'goal':goal,'proof_elapsed_seconds':time.monotonic()-start})
  (base/file).write_text(original[file])
  print(name,'compiled and rejected',flush=True)
finally:
 for name,source in original.items():
  (base/name).write_text(source)
 Path('/task3-evidence/sensitivity/results.json').write_text(json.dumps(results,indent=2)+'\n')
