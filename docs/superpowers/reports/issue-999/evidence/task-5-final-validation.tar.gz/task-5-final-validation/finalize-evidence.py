from pathlib import Path
import hashlib, re, shutil, tarfile, gzip
root=Path.cwd()
sdd=root/".superpowers/sdd/2026-10-19-issue-999-creusot-adoption"
archive=root/"docs/superpowers/reports/issue-999"
for name in ("task-5-fix1-review.md", "task-5-fix2-review.md", "task-5-final-acceptance-report.md", "progress.md"):
    source=sdd/name
    assert source.is_file(), source
    (archive/"records"/name).write_text(source.read_text().rstrip()+"\n")
evidence=sdd/"task-5-evidence/native-ci"
with (archive/"evidence/task-5-final-ci.tar.gz").open("wb") as out:
    with gzip.GzipFile(fileobj=out, mode="wb", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as tar:
            for source in sorted(evidence.rglob("*")):
                if source.is_file():
                    info=tar.gettarinfo(str(source), arcname="task-5-final-ci/"+str(source.relative_to(evidence)))
                    info.uid=info.gid=0; info.uname=info.gname=""; info.mtime=0
                    with source.open("rb") as data: tar.addfile(info,data)
proofs=root/"docs/knowledge/creusot-budget-proofs.md"
updates={proofs:["guide", "record"], root/"docs/knowledge/references/audit-documents.md":["issue-999-adoption"], root/"docs/knowledge/references/design-documents.md":["issue-999-adoption"]}
for page, ids in updates.items():
    text=page.read_text()
    for ident in ids:
        pattern=r"(- id: "+re.escape(ident)+r"\n  resource: ([^\n]+)\n)  revision: [^\n]+\n  working_tree: [^\n]+\n  sha256: [^\n]+"
        match=re.search(pattern,text); assert match, (page,ident)
        source=(page.parent/match.group(2)).resolve()
        replacement=match.group(1)+"  revision: 312be2c4759be00a26e2f04519258f1172057a67\n  working_tree: modified\n  sha256: "+hashlib.sha256(source.read_bytes()).hexdigest()
        text=text[:match.start()]+replacement+text[match.end():]
    page.write_text(text)
files=sorted(p for p in archive.rglob("*") if p.is_file() and p.name!="SHA256SUMS")
(archive/"SHA256SUMS").write_text("".join(hashlib.sha256(p.read_bytes()).hexdigest()+"  "+str(p.relative_to(archive))+"\n" for p in files))
print(f"Archived {len(files)} files; final CI includes {sum(p.is_file() for p in evidence.rglob('*'))} files")
