from pathlib import Path
import hashlib,json,tarfile
root=Path.cwd(); archive=root/"docs/superpowers/reports/issue-999"; sdd=root/".superpowers/sdd/2026-10-19-issue-999-creusot-adoption"
lines=(archive/"SHA256SUMS").read_text().splitlines(); listed=set()
for line in lines:
    digest,name=line.split("  ",1); path=archive/name
    assert path.is_file(),name
    assert hashlib.sha256(path.read_bytes()).hexdigest()==digest,name
    listed.add(name)
actual={str(p.relative_to(archive)) for p in archive.rglob("*") if p.is_file() and p.name!="SHA256SUMS"}
assert listed==actual,(listed^actual)
source=(sdd/"progress.md").read_text(); copied=(archive/"records/progress.md").read_text()
rulings=[line for line in source.splitlines() if line.startswith("Ruling:")]
assert rulings==[line for line in copied.splitlines() if line.startswith("Ruling:")]
assert len(rulings)==7
for name in ("task-5-fix1-review.md","task-5-fix2-review.md","task-5-final-acceptance-report.md"):
    assert (sdd/name).read_text().rstrip()==(archive/"records"/name).read_text().rstrip(),name
native=sdd/"task-5-evidence/native-ci"; archived_native=0
with tarfile.open(archive/"evidence/task-5-final-ci.tar.gz","r:gz") as tar:
    for member in tar.getmembers():
        assert member.isfile(),member.name
        rel=Path(member.name).relative_to("task-5-final-ci")
        assert tar.extractfile(member).read()==(native/rel).read_bytes(),member.name
        archived_native+=1
assert archived_native==sum(p.is_file() for p in native.rglob("*"))
metadata=json.loads((native/"non-linux-final-312be-metadata.json").read_text())
assert metadata["headSha"]=="312be2c4759be00a26e2f04519258f1172057a67"
assert metadata["status"]=="completed" and metadata["conclusion"]=="success"
assert len(metadata["jobs"])==9 and all(job["conclusion"]=="success" for job in metadata["jobs"])
print(json.dumps({"archive_files_verified":len(listed),"controller_rulings_preserved":len(rulings),"native_evidence_files_byte_verified":archived_native,"final_native_jobs_successful":len(metadata["jobs"]),"historical_review_copies_preserved":2},indent=2))
